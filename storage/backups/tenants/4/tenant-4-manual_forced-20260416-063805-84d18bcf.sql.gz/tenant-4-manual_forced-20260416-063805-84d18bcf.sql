-- Tenant backup snapshot
-- tenant_id: 4
-- created_at: 2026-04-16 06:38:05
SET time_zone = '+08:00';
SET FOREIGN_KEY_CHECKS = 0;
DELETE FROM `transaction_items` WHERE `tenant_id` = 4;
DELETE FROM `transactions` WHERE `tenant_id` = 4;
DELETE FROM `product_ingredients` WHERE `tenant_id` = 4;
DELETE FROM `inventory_movements` WHERE `tenant_id` = 4;
DELETE FROM `damaged_items` WHERE `tenant_id` = 4;
DELETE FROM `expenses` WHERE `tenant_id` = 4;
DELETE FROM `products` WHERE `tenant_id` = 4;
DELETE FROM `ingredients` WHERE `tenant_id` = 4;
DELETE FROM `categories` WHERE `tenant_id` = 4;
DELETE FROM `activity_logs` WHERE `tenant_id` = 4;
DELETE FROM `users` WHERE `tenant_id` = 4;
INSERT INTO `tenants` (`id`, `parent_tenant_id`, `branch_group_id`, `name`, `slug`, `plan`, `is_active`, `is_main_branch`, `license_starts_at`, `license_expires_at`, `created_at`, `updated_at`, `paid_amount`, `max_branches`, `receipt_phone`, `receipt_address`, `receipt_email`, `receipt_display_name`, `receipt_business_style`, `receipt_tax_id`, `receipt_footer_note`, `receipt_lan_print_copies`) VALUES (4, 4, 4, 'MPG Technology Solutions', 'mpg-technology-solutions', 'trial', 1, 1, '2026-04-16 06:09:01', '2026-04-19 06:09:01', '2026-04-16 06:09:01', '2026-04-16 06:09:01', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1) ON DUPLICATE KEY UPDATE `parent_tenant_id` = VALUES(`parent_tenant_id`), `branch_group_id` = VALUES(`branch_group_id`), `name` = VALUES(`name`), `slug` = VALUES(`slug`), `plan` = VALUES(`plan`), `is_active` = VALUES(`is_active`), `is_main_branch` = VALUES(`is_main_branch`), `license_starts_at` = VALUES(`license_starts_at`), `license_expires_at` = VALUES(`license_expires_at`), `created_at` = VALUES(`created_at`), `updated_at` = VALUES(`updated_at`), `paid_amount` = VALUES(`paid_amount`), `max_branches` = VALUES(`max_branches`), `receipt_phone` = VALUES(`receipt_phone`), `receipt_address` = VALUES(`receipt_address`), `receipt_email` = VALUES(`receipt_email`), `receipt_display_name` = VALUES(`receipt_display_name`), `receipt_business_style` = VALUES(`receipt_business_style`), `receipt_tax_id` = VALUES(`receipt_tax_id`), `receipt_footer_note` = VALUES(`receipt_footer_note`), `receipt_lan_print_copies` = VALUES(`receipt_lan_print_copies`);
INSERT INTO `users` (`id`, `tenant_id`, `module_permissions`, `name`, `email`, `role`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (6, 4, NULL, 'Marvin Pardillo Gulle', 'gullemarvin@gmail.com', 'tenant_admin', '2026-04-16 06:09:01', '$2y$10$ZCQpxnabNHavMLcDSvcpEelU2p/Wr7nhUDOkJSQ1GmvVe74oJcfTe', NULL, '2026-04-16 06:09:01', '2026-04-16 06:09:01');
INSERT INTO `ingredients` (`id`, `tenant_id`, `name`, `unit`, `category`, `unit_cost`, `stock_quantity`, `low_stock_threshold`, `created_at`, `updated_at`) VALUES (143, 4, 'tew', 'pc', 'general', '0.0000000000000000', '1.0000000000000000', '1.0000000000000000', '2026-04-16 06:18:35', '2026-04-16 06:18:35');
INSERT INTO `products` (`id`, `tenant_id`, `category_id`, `name`, `price`, `image_path`, `is_active`, `has_flavor_options`, `created_at`, `updated_at`) VALUES (129, 4, NULL, 'dw', '2.0000000000000000', '', 1, 0, '2026-04-16 06:18:53', '2026-04-16 06:18:53');
INSERT INTO `transactions` (`id`, `tenant_id`, `user_id`, `total_amount`, `amount_tendered`, `change_amount`, `payment_method`, `amount_paid`, `refunded_amount`, `added_paid_amount`, `original_total_amount`, `expense_total`, `profit_total`, `status`, `was_updated`, `pending_name`, `pending_contact`, `created_at`, `updated_at`) VALUES (20, 4, 6, '2.0000000000000000', '2.0000000000000000', '0.0000000000000000', 'gcash', '2.0000000000000000', '0.0000000000000000', '0.0000000000000000', '2.0000000000000000', '0.0000000000000000', '2.0000000000000000', 'completed', 0, NULL, NULL, '2026-04-16 06:19:05', '2026-04-16 06:19:05');
INSERT INTO `transaction_items` (`id`, `tenant_id`, `transaction_id`, `product_id`, `flavor_ingredient_id`, `flavor_name`, `flavor_quantity_required`, `quantity`, `unit_price`, `unit_expense`, `line_total`, `line_expense`, `created_at`, `updated_at`) VALUES (61, 4, 20, 129, NULL, NULL, NULL, 1, '2.0000000000000000', '0.0000000000000000', '2.0000000000000000', '0.0000000000000000', '2026-04-16 06:19:05', '2026-04-16 06:19:05');
SET FOREIGN_KEY_CHECKS = 1;
